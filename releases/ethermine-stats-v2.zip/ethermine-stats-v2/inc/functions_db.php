<?php

// Database related functions


?>